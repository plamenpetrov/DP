## Design Patterns in Laravel & PHP

In ths git repository you will find the Gang of Four patterns that go along with the book found at http://leanpub.com/larasign

You can checkout each branch to view the code. For example, if you wanted to checkout the iterator pattern.

```
git checkout iterator
```

Most code is stored in `src/` directory. I did this on purpose so that you didn't have to go hunting in the `app/` directory for code on a design pattern.